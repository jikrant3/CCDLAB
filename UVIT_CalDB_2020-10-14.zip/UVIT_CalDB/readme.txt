Place the extracted folder at the c:\ directory level, i.e.:

c:\UVIT_CalDB